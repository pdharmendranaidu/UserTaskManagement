package com.max.taskproject.serviceImpl;

import org.springframework.stereotype.Service;

import com.max.taskproject.service.TaskService;
@Service
public class TaskServiceImpl implements TaskService {

}
