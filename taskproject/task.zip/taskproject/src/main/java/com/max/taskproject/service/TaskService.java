package com.max.taskproject.service;

public interface TaskService {

}
