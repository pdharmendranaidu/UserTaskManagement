package com.max.taskproject.service;

import com.max.taskproject.payload.UserDto;

public interface UserService {
	
	
	public UserDto createUser(UserDto userDto);

}
